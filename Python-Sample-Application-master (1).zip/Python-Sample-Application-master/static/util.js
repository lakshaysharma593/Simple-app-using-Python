function action(endpoint_name) {
    window.location.replace('/' + endpoint_name);
}

function redirect_to_demo(code) {
    window.location.replace('/demo');
}
