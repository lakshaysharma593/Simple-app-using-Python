from setuptools import setup, find_packages

setup(
    name='Python-Sample-Application',
    version='0.0.1',
    author='Uber Engineering',
    author_email='developer@uber.com',
    packages=find_packages(),
    description='Python sample application',
)
